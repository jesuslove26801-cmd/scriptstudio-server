import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { URL } from "node:url";

// XAI_AUTH_B64 환경변수가 있으면 Base64 디코딩 후 auth.json 파일로 저장
if (process.env.XAI_AUTH_B64) {
  const authDir = path.join(process.env.HOME || "/root", ".grok");
  fs.mkdirSync(authDir, { recursive: true });
  const authFile = path.join(authDir, "auth.json");
  const decoded = Buffer.from(process.env.XAI_AUTH_B64, "base64").toString("utf8");
  fs.writeFileSync(authFile, decoded, { mode: 0o600 });
  console.log("[startup] auth.json written from XAI_AUTH_B64 env var");
}

const HOST = process.env.HOST || "0.0.0.0";
const PORT = Number(process.env.PORT || 8300);
const UPSTREAM_BASE_URL = (process.env.XAI_BASE_URL || "https://api.x.ai/v1").replace(/\/+$/, "");
const DEFAULT_MODEL = process.env.XAI_DEFAULT_MODEL || "grok-4.3";
const AUTH_FILE = process.env.XAI_AUTH_FILE || path.join(process.env.HOME || "/root", ".grok", "auth.json");
const AUTH_FILES = parseAuthFiles(process.env.XAI_AUTH_FILES || "", AUTH_FILE);
const PROXY_API_KEY = process.env.XAI_PROXY_API_KEY || "";
const CLIENT_ID = process.env.XAI_CLIENT_ID || "";
const TOKEN_ENDPOINT = process.env.XAI_TOKEN_ENDPOINT || "";
const BODY_LIMIT_BYTES = Number(process.env.BODY_LIMIT_BYTES || 50 * 1024 * 1024);

const STATIC_MODELS = ["grok-composer-2.5-fast", "grok-build-0.1", "grok-4.3", "grok-4.3-latest", "grok-latest"];

function nowSeconds() {
  return Math.floor(Date.now() / 1000);
}

function parseIsoSeconds(value) {
  if (!value) return 0;
  const ms = Date.parse(value);
  return Number.isFinite(ms) ? Math.floor(ms / 1000) : 0;
}

function isoFromSeconds(seconds) {
  return new Date(seconds * 1000).toISOString();
}

function parseAuthFiles(raw, fallbackFile) {
  const files = [];
  const add = (file) => {
    const value = String(file || "").trim();
    if (value && !files.includes(value)) files.push(value);
  };

  if (raw && raw.trim()) {
    for (const file of raw.split(/[,:]/)) add(file);
  } else {
    add(fallbackFile);
  }

  return files;
}

function jsonResponse(res, status, payload, headers = {}) {
  const body = JSON.stringify(payload);
  res.writeHead(status, {
    "content-type": "application/json",
    "content-length": Buffer.byteLength(body),
    ...headers,
  });
  res.end(body);
}

function corsHeaders() {
  return {
    "access-control-allow-origin": "*",
    "access-control-allow-methods": "GET,POST,OPTIONS",
    "access-control-allow-headers": "Authorization,Content-Type,Accept",
    "access-control-max-age": "86400",
  };
}

function safeReadJson(file) {
  return JSON.parse(fs.readFileSync(file, "utf8"));
}

function atomicWriteJson(file, data) {
  const dir = path.dirname(file);
  const tmp = path.join(dir, `.tmp-${path.basename(file)}-${process.pid}`);
  fs.writeFileSync(tmp, `${JSON.stringify(data, null, 2)}\n`, { mode: 0o600 });
  fs.renameSync(tmp, file);
}

function findGrokEntry(auth) {
  for (const [entryKey, value] of Object.entries(auth || {})) {
    if (value && typeof value === "object" && typeof value.key === "string" && value.refresh_token) {
      return { entryKey, value };
    }
  }
  return null;
}

function loadEnvCredentials() {
  if (!process.env.XAI_ACCESS_TOKEN) return null;
  return {
    format: "env",
    label: "env",
    accessToken: process.env.XAI_ACCESS_TOKEN,
    refreshToken: process.env.XAI_REFRESH_TOKEN || "",
    expiresAt: Number(process.env.XAI_EXPIRES_AT || 0),
    clientId: CLIENT_ID,
    tokenEndpoint: TOKEN_ENDPOINT || "https://auth.x.ai/oauth2/token",
  };
}

function loadCredentials(authFile = AUTH_FILE, index = 0) {
  const auth = safeReadJson(authFile);
  const provider = auth?.providers?.["xai-oauth"];
  if (provider?.tokens?.access_token) {
    const lastRefresh = parseIsoSeconds(provider.last_refresh);
    const expiresIn = Number(provider.tokens.expires_in || 0);
    return {
      format: "hermes",
      authFile,
      label: `auth#${index + 1}:${path.basename(authFile)}`,
      raw: auth,
      email: provider.userinfo?.email || provider.email || null,
      accessToken: provider.tokens.access_token,
      refreshToken: provider.tokens.refresh_token || "",
      expiresAt: provider.tokens.expires_at ? parseIsoSeconds(provider.tokens.expires_at) : lastRefresh + expiresIn,
      clientId: provider.client_id || provider.oidc_client_id || CLIENT_ID,
      tokenEndpoint: provider.discovery?.token_endpoint || TOKEN_ENDPOINT || "https://auth.x.ai/oauth2/token",
    };
  }

  const grokEntry = findGrokEntry(auth);
  if (grokEntry) {
    const issuer = grokEntry.value.oidc_issuer || "https://auth.x.ai";
    return {
      format: "grok",
      authFile,
      label: `auth#${index + 1}:${path.basename(authFile)}`,
      raw: auth,
      entryKey: grokEntry.entryKey,
      email: grokEntry.value.email || null,
      accessToken: grokEntry.value.key,
      refreshToken: grokEntry.value.refresh_token || "",
      expiresAt: parseIsoSeconds(grokEntry.value.expires_at),
      clientId: grokEntry.value.oidc_client_id || CLIENT_ID,
      tokenEndpoint: TOKEN_ENDPOINT || `${issuer.replace(/\/+$/, "")}/oauth2/token`,
    };
  }

  throw new Error(`No usable xAI OAuth credentials in ${authFile}`);
}

function loadCredentialChain() {
  const credentials = [];
  const errors = [];
  const envCredentials = loadEnvCredentials();
  if (envCredentials) credentials.push(envCredentials);

  for (const [index, authFile] of AUTH_FILES.entries()) {
    try {
      credentials.push(loadCredentials(authFile, index));
    } catch (error) {
      errors.push(`${authFile}: ${error.message}`);
    }
  }

  if (!credentials.length) {
    throw new Error(errors.length ? errors.join("; ") : "No xAI OAuth credentials configured");
  }

  return credentials;
}

function saveCredentials(credentials, refreshed) {
  if (credentials.format === "env") return;

  const expiresIn = Number(refreshed.expires_in || 21600);
  const expiresAt = nowSeconds() + expiresIn;
  const nextRefreshToken = refreshed.refresh_token || credentials.refreshToken;

  if (credentials.format === "hermes") {
    const provider = credentials.raw.providers["xai-oauth"];
    provider.tokens.access_token = refreshed.access_token;
    provider.tokens.refresh_token = nextRefreshToken;
    if (refreshed.id_token) provider.tokens.id_token = refreshed.id_token;
    provider.tokens.expires_in = expiresIn;
    provider.tokens.token_type = refreshed.token_type || "Bearer";
    provider.last_refresh = new Date().toISOString();
    atomicWriteJson(credentials.authFile, credentials.raw);
    return;
  }

  if (credentials.format === "grok") {
    const entry = credentials.raw[credentials.entryKey];
    entry.key = refreshed.access_token;
    entry.refresh_token = nextRefreshToken;
    entry.expires_at = isoFromSeconds(expiresAt);
    atomicWriteJson(credentials.authFile, credentials.raw);
  }
}

async function refreshCredentials(credentials) {
  if (!credentials.refreshToken) {
    throw new Error("OAuth access token expired and no refresh_token is available");
  }

  const form = new URLSearchParams();
  form.set("grant_type", "refresh_token");
  form.set("refresh_token", credentials.refreshToken);
  if (credentials.clientId) form.set("client_id", credentials.clientId);

  const response = await fetch(credentials.tokenEndpoint, {
    method: "POST",
    headers: {
      "content-type": "application/x-www-form-urlencoded",
      accept: "application/json",
    },
    body: form,
  });
  const text = await response.text();
  let payload = {};
  try {
    payload = text ? JSON.parse(text) : {};
  } catch {
    payload = { error: "invalid_json", error_description: text.slice(0, 200) };
  }

  if (!response.ok || !payload.access_token) {
    const description = payload.error_description || payload.error || `HTTP ${response.status}`;
    throw new Error(`Token refresh failed: ${description}`);
  }

  saveCredentials(credentials, payload);
  return payload.access_token;
}

async function getAccessToken(credentials = loadCredentialChain()[0]) {
  if (!credentials.expiresAt || credentials.expiresAt - nowSeconds() > 120) {
    return credentials.accessToken;
  }
  return refreshCredentials(credentials);
}

function redactError(error) {
  return String(error?.message || error || "unknown error").slice(0, 240);
}

function shouldFallback(status, text = "") {
  if ([401, 403, 429].includes(status)) return true;
  const lower = text.toLowerCase();
  return [
    "quota",
    "rate limit",
    "rate_limit",
    "limit exceeded",
    "too many",
    "usage",
    "exhausted",
    "insufficient",
    "unauthorized",
    "forbidden",
    "invalid",
    "invalid_token",
    "expired",
    "resource_exhausted",
  ].some((needle) => lower.includes(needle));
}

function requireProxyAuth(req, res) {
  if (!PROXY_API_KEY) return true;
  const auth = req.headers.authorization || "";
  if (auth === `Bearer ${PROXY_API_KEY}`) return true;
  jsonResponse(res, 401, { error: { message: "Unauthorized", type: "invalid_request_error" } }, corsHeaders());
  return false;
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on("data", (chunk) => {
      size += chunk.length;
      if (size > BODY_LIMIT_BYTES) {
        reject(new Error("Request body too large"));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on("end", () => resolve(Buffer.concat(chunks)));
    req.on("error", reject);
  });
}

function cloneHeaders(req, accessToken, bodyLength) {
  const headers = {};
  for (const [key, value] of Object.entries(req.headers)) {
    const lower = key.toLowerCase();
    if (["host", "authorization", "content-length", "connection"].includes(lower)) continue;
    headers[key] = value;
  }
  headers.authorization = `Bearer ${accessToken}`;
  if (bodyLength !== undefined) headers["content-length"] = String(bodyLength);
  return headers;
}

function responseHeaders(upstream) {
  const headers = {};
  upstream.headers.forEach((value, key) => {
    if (["connection", "content-encoding", "transfer-encoding"].includes(key.toLowerCase())) return;
    headers[key] = value;
  });
  return { ...headers, ...corsHeaders() };
}

async function forwardJson(req, res, upstreamPath, bodyMutator) {
  const bodyBuffer = await readBody(req);
  let outgoing = bodyBuffer;
  if (bodyMutator) {
    const payload = bodyBuffer.length ? JSON.parse(bodyBuffer.toString("utf8")) : {};
    if (!payload.model) payload.model = DEFAULT_MODEL;
    outgoing = Buffer.from(JSON.stringify(bodyMutator(payload)));
  }

  const credentials = loadCredentialChain();
  let lastError = null;

  for (let index = 0; index < credentials.length; index += 1) {
    const credential = credentials[index];
    const isLast = index === credentials.length - 1;
    try {
      const accessToken = await getAccessToken(credential);
      const upstream = await fetch(`${UPSTREAM_BASE_URL}${upstreamPath}`, {
        method: req.method,
        headers: cloneHeaders(req, accessToken, outgoing.length),
        body: outgoing,
      });

      if (upstream.ok) {
        res.writeHead(upstream.status, responseHeaders(upstream));
        if (upstream.body) {
          for await (const chunk of upstream.body) res.write(chunk);
        }
        res.end();
        return;
      }

      const text = await upstream.text();
      if (!isLast && shouldFallback(upstream.status, text)) {
        console.warn(`xAI upstream ${upstream.status} from ${credential.label}; trying fallback auth`);
        lastError = new Error(`Upstream ${upstream.status}: ${text.slice(0, 240)}`);
        continue;
      }

      res.writeHead(upstream.status, responseHeaders(upstream));
      res.end(text);
      return;
    } catch (error) {
      lastError = error;
      if (!isLast) {
        console.warn(`xAI request failed with ${credential.label}: ${redactError(error)}; trying fallback auth`);
        continue;
      }
    }
  }

  throw lastError || new Error("xAI upstream request failed");
}

async function forwardGet(req, res, upstreamPath) {
  const credentials = loadCredentialChain();
  let lastError = null;

  for (let index = 0; index < credentials.length; index += 1) {
    const credential = credentials[index];
    const isLast = index === credentials.length - 1;
    try {
      const accessToken = await getAccessToken(credential);
      const upstream = await fetch(`${UPSTREAM_BASE_URL}${upstreamPath}`, {
        method: "GET",
        headers: {
          authorization: `Bearer ${accessToken}`,
          accept: req.headers.accept || "application/json",
        },
      });

      if (upstream.ok) {
        res.writeHead(upstream.status, responseHeaders(upstream));
        if (upstream.body) {
          for await (const chunk of upstream.body) res.write(chunk);
        }
        res.end();
        return;
      }

      const text = await upstream.text();
      if (!isLast && shouldFallback(upstream.status, text)) {
        console.warn(`xAI upstream ${upstream.status} from ${credential.label}; trying fallback auth`);
        lastError = new Error(`Upstream ${upstream.status}: ${text.slice(0, 240)}`);
        continue;
      }

      res.writeHead(upstream.status, responseHeaders(upstream));
      res.end(text);
      return;
    } catch (error) {
      lastError = error;
      if (!isLast) {
        console.warn(`xAI GET failed with ${credential.label}: ${redactError(error)}; trying fallback auth`);
        continue;
      }
    }
  }

  throw lastError || new Error("xAI upstream GET failed");
}

function modelListPayload(baseModels = []) {
  const byId = new Map();
  for (const model of baseModels) {
    if (model && model.id) byId.set(model.id, model);
  }
  for (const id of [DEFAULT_MODEL, ...STATIC_MODELS]) {
    if (id && !byId.has(id)) byId.set(id, { id, object: "model", owned_by: "xai" });
  }
  return { object: "list", data: [...byId.values()] };
}

async function listModels(_req, res) {
  const credentials = loadCredentialChain();
  try {
    for (let index = 0; index < credentials.length; index += 1) {
      const credential = credentials[index];
      const accessToken = await getAccessToken(credential);
      const upstream = await fetch(`${UPSTREAM_BASE_URL}/models`, {
        headers: { authorization: `Bearer ${accessToken}`, accept: "application/json" },
      });
      const text = await upstream.text();
      if (upstream.ok) {
        const payload = modelListPayload(JSON.parse(text).data || []);
        jsonResponse(res, upstream.status, payload, corsHeaders());
        return;
      }
      if (index < credentials.length - 1 && shouldFallback(upstream.status, text)) {
        console.warn(`xAI /models ${upstream.status} from ${credential.label}; trying fallback auth`);
        continue;
      }
      break;
    }
  } catch {
    // Fall back below; /health will expose credential problems more directly.
  }

  jsonResponse(res, 200, modelListPayload(), corsHeaders());
}

async function health(_req, res) {
  try {
    const credentials = loadCredentialChain();
    jsonResponse(res, 200, {
      status: "healthy",
      upstream: UPSTREAM_BASE_URL,
      default_model: DEFAULT_MODEL,
      auth_count: credentials.length,
      auth_files: AUTH_FILES,
      auth_chain: credentials.map((credential) => ({
        label: credential.label,
        format: credential.format,
        email: credential.email || null,
        token_expires_at: credential.expiresAt ? isoFromSeconds(credential.expiresAt) : null,
        has_refresh_token: Boolean(credential.refreshToken),
      })),
    }, corsHeaders());
  } catch (error) {
    jsonResponse(res, 503, { status: "unhealthy", error: error.message }, corsHeaders());
  }
}

const COMPOSER_SYSTEM_PROMPT = process.env.XAI_COMPOSER_SYSTEM_PROMPT
  || `You are Grok, a coding assistant built by xAI. Follow these guidelines, derived from Andrej Karpathy's observations on common LLM coding mistakes. They bias toward caution over speed; for trivial tasks, use judgment.

1. Think Before Coding — Do not assume; do not hide confusion; surface tradeoffs.
- State your assumptions explicitly. If uncertain, ask.
- If multiple interpretations exist, present them; do not pick silently.
- If a simpler approach exists, say so. Push back when warranted.
- If something is unclear, stop, name what is confusing, and ask.

2. Simplicity First — The minimum code that solves the problem. Nothing speculative.
- No features beyond what was asked.
- No abstractions for single-use code.
- No flexibility or configurability that was not requested.
- No error handling for impossible scenarios.
- If you write 200 lines and it could be 50, rewrite it. Ask: would a senior engineer call this overcomplicated? If yes, simplify.

3. Surgical Changes — Touch only what you must. Clean up only your own mess.
- Do not improve adjacent code, comments, or formatting.
- Do not refactor things that are not broken.
- Match existing style, even if you would do it differently.
- If you notice unrelated dead code, mention it; do not delete it.
- Remove imports, variables, and functions that YOUR changes made unused; do not remove pre-existing dead code unless asked.
- Every changed line should trace directly to the user request.

4. Goal-Driven Execution — Define success criteria. Loop until verified.
- Turn tasks into verifiable goals (e.g. 'fix the bug' becomes 'write a test that reproduces it, then make it pass').
- For multi-step tasks, state a brief plan with a verification check per step.
- Loop independently until the success criteria are met.`;

function hasSystemMessage(messages) {
  return Array.isArray(messages) && messages.some(
    (m) => m && m.role === "system" && m.content &&
      (typeof m.content !== "string" || m.content.trim().length > 0)
  );
}

function withSystemPrompt(payload) {
  // grok-composer models return empty / hallucinated output when no system prompt is provided.
  const model = String((payload && payload.model) || "");
  if (model.includes("composer") && Array.isArray(payload.messages) && !hasSystemMessage(payload.messages)) {
    payload.messages = [{ role: "system", content: COMPOSER_SYSTEM_PROMPT }, ...payload.messages];
  }
  return payload;
}

// ── Grok OAuth Device Code 로그인 ──
const ISSUER = "https://auth.x.ai";
const GROK_CLIENT_ID = "b1a00492-073a-47ea-816f-4c329264a828";
const GROK_SCOPE = "openid profile email offline_access api:access grok-cli:access";
let _loginSession = null; // { device_code, verification_uri_complete, user_code, expires_at, polling }

async function handleAuthLogin(req, res) {
  // 이미 로그인된 경우
  const creds = loadCredentialChain();
  if (creds.length > 0) {
    jsonResponse(res, 200, { status: "already_logged_in" }, corsHeaders());
    return;
  }
  // device code 요청
  const form = (o) => new URLSearchParams(o).toString();
  const r = await fetch(`${ISSUER}/oauth2/device/code`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: form({ client_id: GROK_CLIENT_ID, scope: GROK_SCOPE }),
  });
  if (!r.ok) {
    jsonResponse(res, 500, { error: `device/code failed: ${r.status}` }, corsHeaders());
    return;
  }
  const dc = await r.json();
  const verifyUrl = dc.verification_uri_complete || dc.verification_uri;
  const expiresAt = Date.now() + Math.min(900, Number(dc.expires_in || 900)) * 1000;

  // 브라우저 자동 오픈 (Windows)
  try {
    const { exec } = await import("node:child_process");
    exec(`start "" "${verifyUrl}"`);
  } catch(e) {}

  // 백그라운드 폴링 시작
  _loginSession = { polling: true, user_code: dc.user_code, verification_uri_complete: verifyUrl };
  (async () => {
    const interval = Math.max(2, Number(dc.interval || 5)) * 1000;
    while (Date.now() < expiresAt) {
      await new Promise(resolve => setTimeout(resolve, interval));
      const tr = await fetch(`${ISSUER}/oauth2/token`, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: form({ grant_type: "urn:ietf:params:oauth:grant-type:device_code", device_code: dc.device_code, client_id: GROK_CLIENT_ID }),
      });
      const tj = await tr.json().catch(() => ({}));
      if (tr.ok && tj.access_token) {
        // auth.json 저장
        const authDir = path.dirname(AUTH_FILE);
        fs.mkdirSync(authDir, { recursive: true });
        const authData = { [`${ISSUER}::${GROK_CLIENT_ID}`]: {
          key: tj.access_token, auth_mode: "oidc",
          refresh_token: tj.refresh_token || "",
          expires_at: new Date(Date.now() + (tj.expires_in || 7200) * 1000).toISOString(),
          oidc_issuer: ISSUER, oidc_client_id: GROK_CLIENT_ID,
        }};
        fs.writeFileSync(AUTH_FILE, JSON.stringify(authData, null, 2), { mode: 0o600 });
        _loginSession = { polling: false, status: "done" };
        console.log("[auth] Login successful, auth.json saved");
        break;
      }
      if (tj.error === "authorization_pending") continue;
      if (tj.error === "slow_down") { await new Promise(r => setTimeout(r, 3000)); continue; }
      _loginSession = { polling: false, status: "error", error: tj.error };
      break;
    }
    if (_loginSession && _loginSession.polling) _loginSession = { polling: false, status: "expired" };
  })();

  jsonResponse(res, 200, {
    status: "pending",
    verification_url: verifyUrl,
    user_code: dc.user_code,
  }, corsHeaders());
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);

    if (req.method === "OPTIONS") {
      res.writeHead(204, corsHeaders());
      res.end();
      return;
    }

    if (req.method === "GET" && url.pathname === "/health") {
      await health(req, res);
      return;
    }

    // ── 로컬 전용: Grok OAuth 로그인 ──
    if (req.method === "POST" && url.pathname === "/auth/login") {
      await handleAuthLogin(req, res);
      return;
    }
    if (req.method === "GET" && url.pathname === "/auth/status") {
      const creds = loadCredentialChain();
      const loggedIn = creds.length > 0;
      const sessionStatus = _loginSession ? _loginSession.status || (_loginSession.polling ? "pending" : "idle") : "idle";
      jsonResponse(res, 200, {
        logged_in: loggedIn,
        auth_count: creds.length,
        login_status: loggedIn ? "done" : sessionStatus,
        verification_url: _loginSession ? _loginSession.verification_uri_complete : null,
        user_code: _loginSession ? _loginSession.user_code : null,
      }, corsHeaders());
      return;
    }
    if (req.method === "POST" && url.pathname === "/auth/logout") {
      try {
        if (fs.existsSync(AUTH_FILE)) fs.unlinkSync(AUTH_FILE);
        jsonResponse(res, 200, { ok: true }, corsHeaders());
      } catch(e) {
        jsonResponse(res, 500, { error: e.message }, corsHeaders());
      }
      return;
    }

    // ── 이미지 프록시: CORS 우회용 (Grok 결과 외부 URL fetch) ──
    if (req.method === "GET" && url.pathname === "/proxy-image") {
      if (!requireProxyAuth(req, res)) return;
      const imgUrl = url.searchParams.get("url");
      if (!imgUrl) { jsonResponse(res, 400, { error: "url param required" }, corsHeaders()); return; }
      try {
        const imgRes = await fetch(imgUrl);
        if (!imgRes.ok) throw new Error("upstream " + imgRes.status);
        const contentType = imgRes.headers.get("content-type") || "image/png";
        const buf = Buffer.from(await imgRes.arrayBuffer());
        const headers = { ...corsHeaders(), "Content-Type": contentType, "Content-Length": buf.length };
        res.writeHead(200, headers);
        res.end(buf);
      } catch(e) {
        jsonResponse(res, 502, { error: e.message }, corsHeaders());
      }
      return;
    }

    if (!url.pathname.startsWith("/v1/")) {
      jsonResponse(res, 404, { error: { message: "Not found" } }, corsHeaders());
      return;
    }

    if (!requireProxyAuth(req, res)) return;

    if (req.method === "GET" && url.pathname === "/v1/models") {
      await listModels(req, res);
      return;
    }

    if (req.method === "GET" && /^\/v1\/videos\/[^/]+$/.test(url.pathname)) {
      await forwardGet(req, res, url.pathname.replace(/^\/v1/, ""));
      return;
    }

    if (req.method === "POST" && url.pathname === "/v1/chat/completions") {
      await forwardJson(req, res, "/chat/completions", withSystemPrompt);
      return;
    }

    if (req.method === "POST" && url.pathname === "/v1/responses") {
      await forwardJson(req, res, "/responses", withSystemPrompt);
      return;
    }

    if (req.method === "POST" && url.pathname === "/v1/images/generations") {
      await forwardJson(req, res, "/images/generations", (payload) => payload);
      return;
    }

    if (req.method === "POST" && url.pathname === "/v1/images/edits") {
      await forwardJson(req, res, "/images/edits", (payload) => payload);
      return;
    }

    if (req.method === "POST" && url.pathname === "/v1/videos/generations") {
      await forwardJson(req, res, "/videos/generations", (payload) => payload);
      return;
    }

    if (req.method === "POST" && url.pathname === "/v1/videos/edits") {
      await forwardJson(req, res, "/videos/edits", (payload) => payload);
      return;
    }

    if (req.method === "POST" && url.pathname === "/v1/videos/extensions") {
      await forwardJson(req, res, "/videos/extensions", (payload) => payload);
      return;
    }

    jsonResponse(res, 404, { error: { message: "Unsupported endpoint" } }, corsHeaders());
  } catch (error) {
    jsonResponse(res, 500, { error: { message: error.message, type: "server_error" } }, corsHeaders());
  }
});

server.listen(PORT, HOST, () => {
  console.log(`xai-oauth-proxy listening on http://${HOST}:${PORT}`);
});
