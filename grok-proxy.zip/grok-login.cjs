#!/usr/bin/env node
// xAI / Grok OAuth login via the OAuth 2.0 Device Authorization Grant.
// No browser on this box is required — you authorize on ANY device. On success it
// writes ~/.grok/auth.json in the format the proxy reads. No npm deps (Node 18+ fetch).
//
//   node grok-login.js                 # log in, write the auth file
//   XAI_AUTH_FILE=/path node grok-login.js
const fs = require('fs');
const os = require('os');
const path = require('path');

const ISSUER = (process.env.XAI_ISSUER || 'https://auth.x.ai').replace(/\/+$/, '');
const CLIENT_ID = process.env.XAI_CLIENT_ID || 'b1a00492-073a-47ea-816f-4c329264a828';
const SCOPE = process.env.XAI_SCOPE || 'openid profile email offline_access api:access grok-cli:access';
const AUTH_FILE = process.env.XAI_AUTH_FILE || path.join(os.homedir(), '.grok', 'auth.json');

const form = (o) => new URLSearchParams(o);

async function main() {
  // 1) request a device code
  let r = await fetch(`${ISSUER}/oauth2/device/code`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: form({ client_id: CLIENT_ID, scope: SCOPE }),
  });
  if (!r.ok) throw new Error(`device/code ${r.status}: ${(await r.text()).slice(0, 300)}`);
  const dc = await r.json();

  console.log('\n  ┌──────────────────────────────────────────────────────────────');
  console.log('  │  Log in to xAI / Grok:');
  console.log('  │    URL : ' + (dc.verification_uri_complete || dc.verification_uri));
  console.log('  │    Code: ' + dc.user_code);
  console.log('  │  (open the URL on any device, sign in, approve)');
  console.log('  └──────────────────────────────────────────────────────────────');
  console.log('  Waiting for authorization...');

  // 2) poll the token endpoint
  let interval = Math.max(2, Number(dc.interval || 5)) * 1000;
  const deadline = Date.now() + Math.min(900, Number(dc.expires_in || 900)) * 1000;
  let tok = null;
  while (Date.now() < deadline) {
    await new Promise((res) => setTimeout(res, interval));
    const tr = await fetch(`${ISSUER}/oauth2/token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: form({ grant_type: 'urn:ietf:params:oauth:grant-type:device_code', device_code: dc.device_code, client_id: CLIENT_ID }),
    });
    const tj = await tr.json().catch(() => ({}));
    if (tr.ok && tj.access_token) { tok = tj; break; }
    if (tj.error === 'authorization_pending') continue;
    if (tj.error === 'slow_down') { interval += 2000; continue; }
    throw new Error(`token: ${tj.error || tr.status} ${tj.error_description || ''}`);
  }
  if (!tok) throw new Error('login timed out — run again.');

  // 3) write auth.json (grok format the proxy understands)
  const expiresAt = new Date(Date.now() + Number(tok.expires_in || 0) * 1000).toISOString();
  const data = {
    [`${ISSUER}::${CLIENT_ID}`]: {
      key: tok.access_token,
      auth_mode: 'oidc',
      refresh_token: tok.refresh_token || '',
      expires_at: expiresAt,
      oidc_issuer: ISSUER,
      oidc_client_id: CLIENT_ID,
    },
  };
  fs.mkdirSync(path.dirname(AUTH_FILE), { recursive: true, mode: 0o700 });
  const tmp = AUTH_FILE + '.tmp-' + process.pid;
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2) + '\n', { mode: 0o600 });
  fs.renameSync(tmp, AUTH_FILE);
  console.log('\n  ✓ Logged in. Wrote ' + AUTH_FILE + (tok.refresh_token ? ' (with refresh token).' : ' (no refresh token — re-login when it expires).'));
}

main().catch((e) => { console.error('\n  ✗ login failed:', e.message); process.exit(1); });
